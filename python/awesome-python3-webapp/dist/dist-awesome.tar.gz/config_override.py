# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 21:24:53 2018

@author: Administrator
"""

configs = {
    'db': {
        #服务器上需要修改一下
         'password':'29pB0078'
    }
}