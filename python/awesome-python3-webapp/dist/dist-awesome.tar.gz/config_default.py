# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 21:18:08 2018

@author: Administrator
"""
#a=r"\\\t\\"
#print(a)

configs = {
        'db':{
            'host':'127.0.0.1',
            'port':3306,
            'user':'root',
            'password':'123456',
            'database':'awesome'
            },
        'session':{
                'secret':'AwEsOmE'
                }
        }
